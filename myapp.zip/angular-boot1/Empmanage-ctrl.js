 (function () {
    "use strict";
    
    angular.module("app")
        .controller("EmpManage", Empinfo);//registering the controller

    Empinfo.$inject = ["personalinfo","$state"];


    function Empinfo(pinfo,$state) {
        var vm = this;
        
        vm.info = {};
        vm.display = {};
        vm.dataArr = [];
        vm.status = { isFirstOpen: true, isFirstDisabled: false };
        vm.tabs = [];
        vm.alerts = [];
        vm.showinfo = showinfo;
        vm.deleteinfo = deleteinfo;
        vm.PhoneNumberP = /^\+?\d{2}[- ]?\d{3}[- ]?\d{5}$/;

        function showinfo() {
            //  vm.addAlert();
            console.log(vm.info);
            var pinfo1 = pinfo;
            var info = angular.copy(vm.info);
            pinfo1.addpinfo(info);
            vm.dataArr = pinfo1.getpinfo();
            vm.addAlert();
        }


        //   code for date picker
        vm.today = function () {
            vm.dt = new Date();
        };
        vm.today();

        vm.clear = function () {
            vm.dt = null;
        };

        // Disable weekend selection
        vm.disabled = function (date, mode) {
            return (mode === 'day' && (date.getDay() === 0 || date.getDay() === 6));
        };

        vm.toggleMin = function () {
            vm.minDate =vm.minDate ? null : new Date();
        };
        vm.toggleMin();

        vm.open = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();

            vm.display.opened = true;
        };

        vm.dateOptions = {
            formatYear: 'yy',
            startingDay: 1
        };

        vm.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy'];
        vm.format = vm.formats[0];



        //function for adding alert on main form 
        vm.addAlert = function () {
            vm.alerts.push({ msg: 'Data Saved Successfully' });
        };

        vm.closeAlert = function (index) {
            vm.alerts.splice(index, 1);
        }; //end of alert function code 




        function deleteinfo(index) {
            vm.dataArr.splice(index, 1);
        }

    }




    //defining factory for personal information

    angular.module("app").factory("personalinfo", pinfo);

    pinfo.$inject = [];

    function pinfo() {
        var dataArr = [];

        return {
            addpinfo: _addpinfo,
            getpinfo: _getpinfo
        }


        function _addpinfo(info) {
            dataArr.push(info);
        }

        function _getpinfo() {
            return dataArr;
        }
    }


})();
